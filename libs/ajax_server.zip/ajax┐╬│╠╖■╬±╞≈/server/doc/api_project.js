define({
  "name": "server",
  "version": "1.0.0",
  "description": "",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2020-07-26T14:37:00.260Z",
    "url": "http://apidocjs.com",
    "version": "0.24.0"
  }
});
